# Готовые веса

`src/predict.py` ищет финальные модели сначала в `outputs/<имя>/`, потом здесь, в `models/<имя>/`.
Чтобы сделать прогноз без переобучения, положите сюда четыре папки финальных моделей:

```text
models/
  final_tcn_h128/      final_seed0.pt  final_seed1.pt  final_seed2.pt  glob_norm.npz  result_final.json
  final_gru_h128l3/    ...
  final_tcn_h128e60/   ...
  final_gru_h96l3/     ...
```

Эти папки создаёт `python reproduce.py final` в `outputs/`. Их можно просто скопировать сюда
(веса весят около 1–3 МБ на модель, `.gitignore` пропускает `*.pt` и `*.npz` внутри `models/`).
